from .graphwave import GraphWave
from .role2vec import Role2Vec
