data_det = {
    "apiKey": "AIzaSyDhr5PJcaWBX15h1PayXSDpM-vsiqHqdUg",
    "authDomain": "explainx-25b88.firebaseapp.com",
    "databaseURL": "https://explainx-25b88.firebaseio.com",
    "projectId": "explainx-25b88",
    "storageBucket": "explainx-25b88.appspot.com",
    "messagingSenderId": "150067985334",
    "appId": "1:150067985334:web:a579d58390dee19837df17",
    "measurementId": "G-SSP86WD8HG",
    "type": "service_account"
}
