style1 = {'backgroundColor': '#fff',
          'color': 'black',
          'border-radius': '15px 15px 0px 0px ',
          'textAlign': 'left',
          'height': "50px",
          'margin': 'auto',
          'padding-left': '70px',
          "font-family": "Helvetica, Arial, sans-serif", }

style2 = {'overflowX': 'auto',
          'margin': 'auto',
          "padding-left": '10px',
          'width': '90%'}

style3 = {
    "fontSize": "15px",
    'marginLeft': "10px",
    'color': 'black',
    'backgroundColor': 'rgb(230, 230, 230)',
    'fontWeight': 'bold'}

style4 = {'backgroundColor': "#fff", 'marginTop': 10, 'marginBottom': 10}

style5 = {'backgroundColor': '#fff',
          'color': 'black',
          'border-radius': '15px 15px 15px 15px ',
          'textAlign': 'left',
          'height': "50px",
          'margin': 'auto',
          'padding-left': '70px',
          'padding-top': '20px'

          }

style6 = {'backgroundColor': '#fff',
          'color': 'black',
          'border-radius': '15px 15px 0px 0px ',
          'textAlign': 'left',
          'height': "50px",
          'margin': 'auto',
          'padding-left': '70px',
         
          }

style7 = {'backgroundColor': "#fff", "minHeight": "400px",
          'border-radius': '15px 15px 15px 15px',
          'box-shadow': '0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19)',
          'border-right': '1px solid #2c3e50', 'border-bottom': '1px solid #2c3e50'}

style8 = {'backgroundColor': '#fff',
          'color': 'black',
          'border-radius': '15px 15px 15px 15px ',
          'textAlign': 'left',
          'height': "50px",
          'margin': 'auto',
          'padding-left': '70px',
          'padding-top': '20px'

          }

style9 = {'backgroundColor': '#fff',
          'color': 'black',
          'border-radius': '15px 15px 0px 0px ',
          'textAlign': 'left',
          'height': "50px",
          'margin': 'auto',
          'padding-left': '70px',
          'padding-top': '20px',
          "font-family": "Helvetica, Arial, sans-serif",

          }

style10 = {'backgroundColor': "#fff", "minHeight": "400px",
           'border-radius': '15px 15px 15px 15px',
           'box-shadow': '0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19)',
           'border-right': '1px solid #2c3e50', 'border-bottom': '1px solid #2c3e50',
           'marginTop': 50}

style11 = {
    "marginTop": 50,
    'border-radius': '15px 15px 15px 15px',

}

style12 = {'backgroundColor': '#fff',
           'color': 'black',
           'border-radius': '15px 15px 15px 15px ',
           'textAlign': 'left',
           'height': "50px",
           'margin': 'auto',
           'padding-left': '70px',
           'padding-top': '20px'

           }

style13 = {'backgroundColor': '#fff',
           'color': 'black',
           'border-radius': '15px 15px 0px 0px ',
           'textAlign': 'left',
           'height': "50px",
           'margin': 'auto',
           'padding-left': '70px',
           'padding-top': '20px',
           "font-family": "Helvetica, Arial, sans-serif",

           }

style14 = {'width': '20%', 'float': 'center', 'display': 'inline-block'}

style15 = {'width': '20%', 'marginRight': 10, 'float': 'center',
           'display': 'inline-block'}

style16 = {'backgroundColor': "#fff", "minHeight": "600px",
           'border-radius': '15px 15px 15px 15px',
           'box-shadow': '0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19)',
           'border-right': '1px solid #2c3e50', 'border-bottom': '1px solid #2c3e50',
           'marginTop': 50, 'width': '100%'}

style17 = {'backgroundColor': '#fff',
           'color': 'black',
           'border-radius': '15px 15px 15px 15px ',
           'textAlign': 'left',
           'height': "50px",
           'margin': 'auto',
           'padding-left': '70px',
           'padding-top': '20px'

           }

style18 = {'backgroundColor': '#fff',
           'color': 'black',
           'border-radius': '15px 15px 0px 0px ',
           'textAlign': 'left',
           'height': "50px",
           'margin': 'auto',
           'padding-left': '70px',
           'padding-top': '20px',
           "font-family": "Helvetica, Arial, sans-serif",

           }

style19 = {'backgroundColor': "#fff", "minHeight": "600px",
           'border-radius': '15px 15px 15px 15px',
           'box-shadow': '0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19)',
           'border-right': '1px solid #2c3e50', 'border-bottom': '1px solid #2c3e50',
           'marginTop': 50, }

style20 = {'marginBottom': 50,
           'marginTop': 50,
           #'marginLeft': "1%",
           'width': '100%', }

style21 = {'backgroundColor': '#fff',
           'color': 'black',
           'border-radius': '15px 15px 15px 15px ',
           'textAlign': 'left',
           'height': "50px",
           'margin': 'auto',
           'padding-left': '70px',
           'padding-top': '20px'

           }

style22 = {'width': '25%', 'marginLeft': 70, 'float': 'left',
           'display': 'inline-block'}

style23 = {'width': '25%', 'marginLeft': 70, 'float': 'left',
           'display': 'inline-block'}

style24 = {'backgroundColor': "#fff", "minHeight": "700px",
           'border-radius': '15px 15px 15px 15px',
           'box-shadow': '0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19)',
           'border-right': '1px solid #2c3e50', 'border-bottom': '1px solid #2c3e50',
           'marginTop': 50}

style25 = {'marginBottom': 50,
           'marginTop': 50,
           'marginLeft': "1%",
           'width': '95%', }

style26 = {'backgroundColor': '#fff',
           'color': 'black',
           'border-radius': '15px 15px 0px 0px ',
           'textAlign': 'left',
           'height': "50px",
           'margin': 'auto',
        #    'padding-left': '70px',
           'padding-top': '20px',
           "font-family": "Helvetica, Arial, sans-serif",

           }

style27 = {
    'backgroundColor': '#0984e3',
    'fontWeight': 'normal',
    "fontSize": "15px",
    'marginLeft': "10px",
    'color': 'white'
}

style28 = {'backgroundColor': "#fff", "minHeight": "200px",
           'border-radius': '15px 15px 15px 15px',
           'box-shadow': '0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19)',
           'border-right': '1px solid #2c3e50', 'border-bottom': '1px solid #2c3e50',
           'marginTop': 50}

style29 = {'backgroundColor': '#fff',
           'color': 'black',
           'border-radius': '15px 15px 15px 15px ',
           'textAlign': 'left',
           'height': "50px",
           'margin-left': '50px',
           'padding-top': '10px'

           }

style30 = {'backgroundColor': '#fff',
           'color': 'black',
           'border-radius': '15px 15px 0px 0px ',
           'textAlign': 'left',
           'height': "50px",
           'margin-left': '50px',
          
           
           }

style31 = {'backgroundColor': "#fff", "minHeight": "400px",
           'border-radius': '15px 15px 15px 15px',
           'box-shadow': '0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19)',
           'border-right': '1px solid #2c3e50',
           'border-bottom': '1px solid #2c3e50', 'marginTop': 50}

style32 = {
    "marginTop": 50,
    'border-radius': '15px 15px 15px 15px'}

style33 = {'backgroundColor': '#fff',
           'color': 'black',
           'border-radius': '15px 15px 0px 0px ',
           'textAlign': 'left',
           'height': "50px",
           'margin': 'auto',
           'padding-left': '70px',
           'padding-top': '20px',
           "font-family": "Helvetica, Arial, sans-serif",

           }

style34 = {'backgroundColor': '#fff',
           'color': 'black',
           'border-radius': '15px 15px 15px 15px ',
           'textAlign': 'left',
           'height': "50px",
           'margin': 'auto',
           'margin-left': '70px',
           "font-family": "Helvetica, Arial, sans-serif",

           }

style35 = {'backgroundColor': '#fff',
           'color': 'black',
           'border-radius': '15px 15px 0px 0px ',
           'textAlign': 'left',
           'height': "50px",
           'margin': 'auto',
           'padding-left': '70px',
           'padding-top': '20px',
           "font-family": "Helvetica, Arial, sans-serif",

           }

style36 = {'overflowX': 'scroll', 'margin': 'auto',
           "padding-left": '30px', 'width': '95%'}

style37 = {
    'backgroundColor': '#0984e3',
    'fontWeight': 'bold',
    "fontSize": "15px",
    'marginLeft': "10px",
    'textAlign': 'center',
    'color': 'white'
}


style39 = {'backgroundColor': "#fff", "minHeight": "800px",
           'border-radius': '15px 15px 15px 15px',
           'box-shadow': '0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19)',
           'border-right': '1px solid #2c3e50', 'border-bottom': '1px solid #2c3e50',
           'marginTop': 50, 'width': '100%'}

style40 = {'marginBottom': 50,
           'marginTop': 10,
           'marginLeft': "1%",
           'marginRight': "1%",
           'width': '97%'}
