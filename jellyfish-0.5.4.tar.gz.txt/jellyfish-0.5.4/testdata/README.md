Test data for jellyfish string comparison and phonetic encoding algorithms.
