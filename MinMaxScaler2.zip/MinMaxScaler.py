#!/usr/bin/env python
# coding: utf-8

# In[7]:


#Program1.1-0
import numpy as np
data = np.array([4, 9, 3, 10, 0, 2])
print(data)


# In[8]:


#Program1.1-1
import numpy as np
data = np.array([4, 9, 3, 10, 0, 2])

def Max(data):
    import numpy as np
    return(np.amax(data))

print(Max(data))


# In[10]:


#Program1.1-2
import numpy as np
data = np.array([4, 9, 3, 10, 0, 2])


def Min(data):
    import numpy as np
    return(np.amin(data))
print(Min(data))


# In[14]:


#Program1.1-3
import numpy as np
data = np.array([4, 9, 3, 10, 0, 2])


def MinMaxScaler(data):
    import numpy as np
    vMin, vMax = Min(data), Max(data)
    data_scaled = (data - vMin) / (vMax - vMin)
    return(data_scaled)

print(MinMaxScaler(data))


# In[ ]:




