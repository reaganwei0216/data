def swish(x):
    return x * x.sigmoid()
