void ignoreDebugOutput(void);
