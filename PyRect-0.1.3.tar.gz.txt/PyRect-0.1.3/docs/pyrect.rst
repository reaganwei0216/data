pyrect package
==============

Module contents
---------------

.. automodule:: pyrect
    :members:
    :undoc-members:
    :show-inheritance:
