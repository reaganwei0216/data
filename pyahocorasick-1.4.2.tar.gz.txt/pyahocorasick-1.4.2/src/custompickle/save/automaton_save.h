#pragma once

#include "../../../common.h"

PyObject*
automaton_save(PyObject* self, PyObject* args);

