This directory contains a simpler pure python module, compatible with Python 2
and 3. It has a slightly different API.  It may fail at pickling for long keys.
